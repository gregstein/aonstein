These replays were downloaded from https://ageofnotes.com

Original Post: https://ageofnotes.com/tutorials/play-without-boars-and-sheep/

Uploaded By GregStein
