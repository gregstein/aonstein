
     ___       _______  _______   ______    _______ .__   __.   ______   .___________. _______     _______.     ______   ______   .___  ___. 
    /   \     /  _____||   ____| /  __  \  |   ____||  \ |  |  /  __  \  |           ||   ____|   /       |    /      | /  __  \  |   \/   | 
   /  ^  \   |  |  __  |  |__   |  |  |  | |  |__   |   \|  | |  |  |  | `---|  |----`|  |__     |   (----`   |  ,----'|  |  |  | |  \  /  | 
  /  /_\  \  |  | |_ | |   __|  |  |  |  | |   __|  |  . `  | |  |  |  |     |  |     |   __|     \   \       |  |     |  |  |  | |  |\/|  | 
 /  _____  \ |  |__| | |  |____ |  `--'  | |  |     |  |\   | |  `--'  |     |  |     |  |____.----)   |    __|  `----.|  `--'  | |  |  |  | 
/__/     \__\ \______| |_______| \______/  |__|     |__| \__|  \______/      |__|     |_______|_______/    (__)\______| \______/  |__|  |__| 
                                                                                                                                             

===================
Where to extract ?
==================

Two methods in which you can extract recorded games:

=>Manual

- Extract recorded games to: %userprofile%\Games\Age of Empires 2 DE\Random Numbers\savegame.

=> Automated

1- Download & Install the open source software DEReplays Manager "DERMSetup-X.X.X.exe" from the releases page: https://github.com/gregstein/DE-Replays-Manager/releases
2- Run DEReplays Manager > Browse Replays tab > Click "Import" button to import the recorded games zip file.

=====================
How to Watch Replays?
=====================
Run AoE2 DE > Single Player > Load Games > Replays tab.
-------------------------
Recorded collected [From AoEZone.com] and provided by https://Ageofnotes.com. Check out our blog for unique tips, and tactics to get better at age of empires 2.