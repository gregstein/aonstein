Turtle Pack, a game data editing software package of AOE1, AOE2 and Star Wars,  was called SLP Editor before.

it includes 3 tools, as follow:

DRS Editor -- can be used for modifying the game data file
SLP Editor --can be used for modifying the game images 
Animation Preview --can be used to do visual evaluating specially for SLP images 

This is a well-designed software, you will feel like using it for its convenience.

------------------------

About the Language:

The default language of Turtle Pack is English. You can check in the languages 
folder to see if your preferred language is available - if yes, copy the language.lg 
to the main directory and replace the original one; if not, you may used notepad or 
other text editor to edit and translate the language.lg you are your language. 
When modifying language.lg, remember to keep the original texts in the same lines.


by Ruralist
mail xflypig@gmail.com
web http://nniu.net
2012.06.26



